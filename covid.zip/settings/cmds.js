var func = require("./functions.js");
var { config } = require("./config.js");
var cmds = [];

var cmd = (name, rights, func) => {
		cmds.push([name, rights, func]);
		}
		
		cmd(/^(?:eval)\s([^]+)$/i, 0, (send, users, vk, msg) => {
	if(i.id != config.creator.id) return;
try{
var evtext = eval(args[1]);
send(`Итог: ${evtext}
•Тип: ${typeof(evtext)}`);
}catch(err){
send("(×)error: "+err.toString());
}
});

cmd(/^(?:Старт|Начать|Начало|Приступить)$/i, 0, (send, users, vk, msg) => {
		msg.send("👿По миру распространился смертельный вирус лекарств от которого нет. Есть лишь один способ выжить - это использовать таблетки которые затормаживают смерть человека. Все игроки борятся за эти таблетки, лишь силнейший сможет получить их. Ведь для получения таблеток необходимо заразить здоровых людей. Удачи, а мне пора на охоту...\n\n📕 » Пишите 'Помощь' для просмотра списка комманд.", {keyboard: JSON.stringify({buttons: [[{action: {type: "text", label: "📓Помощь"}, color: "positive"}]], inline: true})});
		});
		
		cmd(/^(?:Помощь|Команды|help|📓Помощь)$/i, 0, (send, users, vk, msg) => {
msg.send(`📓Список команд ${config.bot.name}:
👶 » Профиль - информация о вашем аккаунте.
💊 » Таблетка - принять таблетку.
👿 » Заразить - заразить вирусом игроков.
📝 » Имя [текст] - сменить имя.
🔁 » Передать [ид] [кол-во] - передать таблетки.
🎁 » Бонус - ежедневный подарок.
👑 » Топ - лучшие игроки.
`, {keyboard: JSON.stringify({buttons: [[{action: {type: "text", label: "👶Профиль"}, color: "positive"}, {action: {type: "text", label: "💊Таблетка"}, color: "positive"}], [{action: {type: "text", label: "🎁Бонус"}, color: "primary"}, {action: {type: "text", label: "👑Топ"}, color: "primary"}], [{action: {type: "text", label: "👿Заразить"}, color: "negative"}]], inline: true})});
});

cmd(/^(?:Профиль|Проф|👶Профиль|Акк|Аккаунт)$/i, 0, (send, users, vk, msg) => {
	var dp1 = (i.uid == 0) ? (``): (`
📆Вы заражены: ${i.date} игроком [id${i.user}|${users.find(x=> x.id == i.user).name}]
`);
msg.send(`[👶]Ваш профиль:  
📝Имя: ${i.name}
🍁ID: ${i.uid}
💊Таблеток: ${func.sp(i.tablets)}
💜Прожито: ${func.timer(i.hp)}
💀Осталось жить: ${func.timer(i.life)}
👿Вами заражено: ${func.sp(i.views)} человек
${dp1}
🌞Для увеличения срока жизни вам необходимо принять таблетку.
🌚Таблетки выдаются за заражения других игроков.`, {keyboard: JSON.stringify({buttons: [[{action: {type: "text", label: "💊Таблетка"}, color: "positive"}], [{action: {type: "text", label: "👿Заразить"}, color: "negative"}]], inline: true})});
});

cmd(/^(?:Таблетка|💊Таблетка)(\s([^]+)|)$/i, 0, (send, users, vk, msg) => {
var count = 0;
	 if(args[1]){
		var count = args[1].replace(/(k|к)/ig, 000).replace(/(все|всё)/ig, i.tablets);
if(!Number(count) || count < 1) return send("❌Кол-во таблеток введено некорректно!");
var count = Number(Number(count).toFixed(0));
		}else{
			var count = (1);
			};
if(i.tablets < count) return send("❌У вас нет столько таблеток!");
i.tablets -= (count);
i.life += (3600*count);
send(`😸Вы приняли ${func.sp(count)} таблеток, ваша жизнь продлена на ${count}ч.`);
});

cmd(/^(?:Заразить|👿Заразить)$/i, 0, (send, users, vk, msg) => {
var link = (config.group.replace("https://vk.com/", "vk.me/")+"?ref="+i.id);
send("😷Распространяйте свою заражённую ссылку, люди перешедшие по ней и написавшие боту будут заражены, вам начислят 5 таблеток за каждого заражённого!\n\n⚠В случае если не получается заразиться по ссылке, то пусть ваша жертва напишет боту данный код: "+i.id);
vk.api.utils.getShortLink({url: link}).then((res) => {
send(res.short_url);
     });
});

cmd(/^(?:Имя|Ник)\s([^]+)$/i, 0, (send, users, vk, msg) => {
if(args[1].length > 25) return send("❌Длина имени не должна быть длиннее 25 символов!");
i.name = args[1];
send("😉Вы успешно сменили имя!");
});

cmd(/^(?:Передать)\s([^]+)\s([^]+)$/i, 0, (send, users, vk, msg) => {
if(!users[args[1]] || users[args[1]].user == false) return send("❌Игрок не найден!");
if(users[args[1]].id == i.id){
	if(i.quest.pay == false) {
		i.tablets += 7;
		send("👏Мы дарим вам 7 таблеток за достижение 'Передача самому себе'!");
		};
		if(i.quest.pay == true) send("😸Не баг, а ФИЧА)");
		i.quest.pay = true;
	};
var sum = args[2].replace(/(k|к)/ig, 000).replace(/(все|всё)/ig, i.tablets);
if(!Number(sum) || sum < 1) return send("❌Кол-во таблеток введено некорректно!");
var sum = Number(Number(sum).toFixed(0));
if(i.tablets < sum) return send("❌У вас нет столько таблеток!");
i.tablets -= sum;
users[args[1]].tablets += sum;
send("🔁Вы успешно передали таблетки игроку!");
vk.api.messages.send({user_id: users[args[1]].id, message: "🔁Игрок [id"+i.id+"|"+i.name+"]["+i.uid+"] передал вам: "+func.sp(sum)+" таблеток."})
});

cmd(/^(?:Бонус|Подарок|🎁Бонус)$/i, 0, (send, users, vk, msg) => {
if(i.bonus > 0) return send("❌Осталось ждать: "+func.timer(i.bonus));
var tab0 = [1, 2, 3, 5, 7, 10, 15, 25, 40];
tab0 = tab0[func.rand(0, tab0.length-1)];
i.tablets += tab0;
i.bonus = 86400;
send("🎁Вы открыли ежедневный подарок и увидели там: "+func.sp(tab0)+" таблеток.\n(Следующий подарок вы сможете открыть через 24ч.)");
});

cmd(/^(?:Топ|👑Топ)$/i, 0, (send, users, vk, msg) => {
var users0 = users.filter(x=> x.user != false);
var limit0 = (users0.length <= 5) ? users0.length: 5;
var top0 = [];
var top1 = [];
users0.map(x=> {
	top0.push({id: x.id, name: x.name, views: x.views, uid: x.uid});
	});
users0.map(x=> {
	top1.push({id: x.id, name: x.name, hp: x.hp, uid: x.uid});
	});
	var top00 = top0.sort((a, b) => {
		return b.views - a.views
	});
	var top11 = top1.sort((a, b) => {
		return b.hp - a.hp
	});
	var top0$ = ("[👿] Топ 5 по заражённым [👿]");
	var top1$ = ("[⏳] Топ 5 по времени жизни [⏳]");
	for(var $num = 0; $num < limit0; $num++){
		top0$ += ("\n"+($num+1)+". [id"+top00[$num].id+"|"+top00[$num].name+"]["+top00[$num].uid+"] -> "+func.sp(top00[$num].views)+" заражённых");
		}
    for(var $num = 0; $num < limit0; $num++){
		top1$ += ("\n"+($num+1)+". [id"+top11[$num].id+"|"+top11[$num].name+"]["+top11[$num].uid+"] -> "+func.timer(top11[$num].hp));
		}
		send(top0$+"\n\n"+top1$);
});

module.exports = {
	cmds
	};
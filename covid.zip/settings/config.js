var config = {
	creator: {
		id: 564751447, //цифровой ид создателя
		name: "Муслим Гайдаров" //имя создателя
		},
	bot: {
		name: "Cov-19|Bot", //название бота
		version: "1.0" //версия бота
		},
		group: "https://vk.com/public201515712", //ссылка на сообщество
		group_id: "201515712", //цифровой ид сообщества
		group_token: "1b364678670edf3f5dea160397fbbe12fcacd00038e1100b453635a2322e50fb537dbbe39760c4402ccf7" //токен сообщества
	}
	
	module.exports = {
		config
		}
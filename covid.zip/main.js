var fs = require('fs'); 
const { VK } = require('vk-io')
const vk = new VK();

const { cmds } = require('./settings/cmds.js');
var func = require('./settings/functions.js');
var users = require('./database/users.json');
var { config } = require('./settings/config.js');

//Таймеры.
	setInterval(() => {
	fs.writeFileSync('./database/users.json', JSON.stringify(users, null, '\t'));
}, 5000);

setInterval(() => {
	users.map(x=> {
		x.activ++;
		});
}, 1000);

setInterval(() => {
	users.map(x=> {
		x.hp++;
		});
}, 1000);

setInterval(() => {
	users.filter(x=> x.bonus > 0).map(x=> {
		x.bonus--;
		});
}, 1000);

setInterval(() => {
	users.map(x=> {
		x.life--;
		if(x.life <= 0) {
			x.life = 86400;
			x.views = 0;
			x.tablets = 1;
			x.hp = 0;
			vk.api.messages.send({user_id: x.id, message: "💀Болезнь уничтожила ваш организм, вы воскрешены в новом теле!"});
			};
		});
}, 1000);

//Конец таймеров.

vk.setOptions({ token: config.group_token, pollingGroupId: config.group_id});
const { updates, snippets } = vk;

updates.startPolling();
updates.on('message', async (msg) => {
	if(Number(msg.senderId) <= 0) return;
	
	var reg0 = new RegExp("\\[club" + config.group_id + "\\|(.*)\\]", "i");
    var reg1 = new RegExp("\\[club" + config.group_id + "\\|(.*)\\]", "ig");
         if (reg0.test(msg.text)) msg.text = msg.text.replace(reg1, '').trim();
         
const [vk_user] = await vk.api.users.get({ user_id: msg.senderId });
	
	msg.user = msg.senderId;
	
function send(text) {
	msg.send(text)
	}

var us1 = (users.length < 1) ? 1: false;
var li1 = (users.length < 1) ? 86400: 1e+20;

if(!users.find(t=> t.id == msg.user)) {
	users.push({
		id: msg.user, //vk?
		name:  vk_user.first_name, //vk?
		rights: 0,
		activ: 0,
		life: li1,
		hp: 0,
		bonus: 0,
		views: 0,
		quest: {
			pay: false
			},
		tablets: 1,
		user: us1,
		date: func.createDate(),
		uid: users.length
		});
	}
	
	   i = users.find(t=> t.id === msg.user)
	
	if(i.user == false && users.filter(x=> x.user != false && x.id == msg.text).length > 0){
		var u4 = users.find(x=> x.user != false && x.id == msg.text);
		u4.tablets += 5;
		u4.views++;
		i.user = u4.id;
		i.life = 86400;
		msg.text = ("начать");
		vk.api.messages.send({user_id: u4.id, message: `😷Игрок [id${i.id}|${i.name}] перешёл по вашей ссылке и заразился, вы получаете 5 таблеток.`});
		};
	
	if(!msg.payload.message.ref && i.user == false) return msg.send("❌Для начала вам необходимо заразиться!");
	
	if(i.user == false && msg.payload.message.ref){
		var u4 = users.find(x=> x.id == msg.payload.message.ref);
		u4.tablets += 5;
		u4.views++;
		i.user = u4.id;
		i.life = 86400;
		vk.api.messages.send({user_id: u4.id, message: `😷Игрок [id${i.id}|${i.name}] перешёл по вашей ссылке и заразился, вы получаете 5 таблеток.`});
		};
		
		const command = cmds.find(x=> x[0].test(msg.text));
	
	if(!command) return;
	
	i.activ = 0;

	args = msg.text.match(command[0]);
	if(i.rights < command[1]) return;
	command[2](send, users, vk, msg)
	
	})